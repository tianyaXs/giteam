# @giteam/cli-darwin-arm64

Prebuilt binary package for `@giteam/cli` on `darwin/arm64`.
