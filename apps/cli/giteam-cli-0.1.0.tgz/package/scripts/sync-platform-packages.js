#!/usr/bin/env node

import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { cliRoot, listPlatforms } from './platform-manifest.js';

const rootPackagePath = join(cliRoot, 'package.json');
const rootPackage = JSON.parse(readFileSync(rootPackagePath, 'utf8'));
const version = rootPackage.version;

for (const platform of listPlatforms()) {
  mkdirSync(join(platform.packageDir, 'bin'), { recursive: true });
  const packageJson = {
    name: platform.packageName,
    version,
    description: `Prebuilt ${platform.os}/${platform.cpu} binary for @giteam/cli`,
    type: 'module',
    os: [platform.os],
    cpu: [platform.cpu],
    files: ['bin/giteam', 'README.md', 'package.json']
  };
  writeFileSync(join(platform.packageDir, 'package.json'), `${JSON.stringify(packageJson, null, 2)}\n`);
  writeFileSync(
    join(platform.packageDir, 'README.md'),
    `# ${platform.packageName}\n\nPrebuilt binary package for \`@giteam/cli\` on \`${platform.os}/${platform.cpu}\`.\n`
  );
}

console.log(`[giteam] synced ${listPlatforms().length} platform package manifests to version ${version}`);
