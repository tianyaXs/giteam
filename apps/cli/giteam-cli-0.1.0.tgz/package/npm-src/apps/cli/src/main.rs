mod doctor;

use clap::{Args, Parser, Subcommand};
use giteam_core::{control, opencode};
use serde::Serialize;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use std::thread;
use std::time::Duration;

#[derive(Parser, Debug)]
#[command(name = "giteam")]
#[command(about = "Terminal giteam control service", version)]
struct Cli {
    #[command(subcommand)]
    command: Option<Commands>,
}

#[derive(Subcommand, Debug)]
enum Commands {
    Serve {
        #[arg(long, default_value_t = true)]
        warmup: bool,
        #[arg(long)]
        json: bool,
    },
    Status {
        #[arg(long)]
        json: bool,
    },
    PairCode {
        #[arg(long)]
        refresh: bool,
        #[arg(long)]
        json: bool,
    },
    Config {
        #[command(subcommand)]
        command: ConfigCommands,
    },
    Doctor {
        #[arg(long)]
        repo_path: Option<String>,
        #[arg(long)]
        warmup: bool,
        #[arg(long)]
        json: bool,
    },
}

#[derive(Subcommand, Debug)]
enum ConfigCommands {
    Get {
        #[arg(long)]
        json: bool,
    },
    Set(ConfigSetArgs),
}

#[derive(Args, Debug)]
struct ConfigSetArgs {
    #[arg(long)]
    enabled: Option<bool>,
    #[arg(long)]
    host: Option<String>,
    #[arg(long)]
    port: Option<u16>,
    #[arg(long)]
    public_base_url: Option<String>,
    #[arg(long)]
    pair_code_ttl_mode: Option<String>,
    #[arg(long)]
    opencode_port: Option<u16>,
    #[arg(long)]
    repo_path: Option<String>,
    #[arg(long)]
    json: bool,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct ConfigView {
    control: control::ControlServerSettings,
    opencode: opencode::OpencodeServiceSettings,
}

fn print_json<T: Serialize>(value: &T) -> Result<(), String> {
    let text = serde_json::to_string_pretty(value).map_err(|e| format!("serialize json failed: {e}"))?;
    println!("{text}");
    Ok(())
}

fn print_status(json: bool) -> Result<(), String> {
    let info = control::get_control_access_info()?;
    if json {
        return print_json(&info);
    }
    println!("enabled: {}", info.enabled);
    println!("host: {}", info.host);
    println!("port: {}", info.port);
    println!("no_auth: {}", info.no_auth);
    println!("pair_code_ttl_mode: {}", info.pair_code_ttl_mode);
    if !info.no_auth {
        println!("pair_code: {}", info.pair_code);
        println!("expires_at: {}", info.expires_at);
    }
    if !info.local_urls.is_empty() {
        println!("local_urls:");
        for url in info.local_urls {
            println!("  - {url}");
        }
    }
    if !info.public_base_url.trim().is_empty() {
        println!("public_base_url: {}", info.public_base_url);
    }
    Ok(())
}

fn print_pair_code(refresh: bool, json: bool) -> Result<(), String> {
    let pair = if refresh {
        control::refresh_control_pair_code()?
    } else {
        control::get_control_pair_code()?
    };
    if json {
        return print_json(&pair);
    }
    println!("code: {}", pair.code);
    println!("expires_at: {}", pair.expires_at);
    println!("ttl_seconds: {}", pair.ttl_seconds);
    Ok(())
}

fn print_config(json: bool) -> Result<(), String> {
    let view = ConfigView {
        control: control::get_control_server_settings()?,
        opencode: opencode::get_opencode_service_settings()?,
    };
    if json {
        return print_json(&view);
    }
    println!("control:");
    println!("  enabled: {}", view.control.enabled);
    println!("  host: {}", view.control.host);
    println!("  port: {}", view.control.port);
    println!(
        "  public_base_url: {}",
        if view.control.public_base_url.trim().is_empty() {
            "(empty)"
        } else {
            view.control.public_base_url.as_str()
        }
    );
    println!("  pair_code_ttl_mode: {}", view.control.pair_code_ttl_mode);
    println!("opencode:");
    println!("  port: {}", view.opencode.port);
    Ok(())
}

fn update_config(args: ConfigSetArgs) -> Result<(), String> {
    let has_control_change = args.enabled.is_some()
        || args.host.is_some()
        || args.port.is_some()
        || args.public_base_url.is_some()
        || args.pair_code_ttl_mode.is_some();
    let has_opencode_change = args.opencode_port.is_some();
    if !has_control_change && !has_opencode_change {
        return Err("config set requires at least one field to update".to_string());
    }

    let mut control_settings = control::get_control_server_settings()?;
    if let Some(enabled) = args.enabled {
        control_settings.enabled = enabled;
    }
    if let Some(host) = args.host {
        control_settings.host = host;
    }
    if let Some(port) = args.port {
        control_settings.port = port;
    }
    if let Some(public_base_url) = args.public_base_url {
        control_settings.public_base_url = public_base_url;
    }
    if let Some(pair_code_ttl_mode) = args.pair_code_ttl_mode {
        control_settings.pair_code_ttl_mode = pair_code_ttl_mode;
    }
    if has_control_change {
        control_settings = control::set_control_server_settings(control_settings)?;
    }

    let mut opencode_settings = opencode::get_opencode_service_settings()?;
    if let Some(port) = args.opencode_port {
        opencode_settings.port = port;
        opencode_settings =
            opencode::set_opencode_service_settings(opencode_settings, normalize_repo_path(args.repo_path)?)?;
    }

    let view = ConfigView {
        control: control_settings,
        opencode: opencode_settings,
    };
    if args.json {
        return print_json(&view);
    }
    print_config(false)
}

fn run_doctor(repo_path: Option<String>, warmup: bool, json: bool) -> Result<(), String> {
    let report = doctor::build_report(repo_path, warmup)?;
    if json {
        return print_json(&report);
    }
    println!("{}", doctor::render_human(&report));
    Ok(())
}

fn normalize_repo_path(repo_path: Option<String>) -> Result<Option<String>, String> {
    let Some(repo_path) = repo_path else {
        return Ok(None);
    };
    let trimmed = repo_path.trim().to_string();
    if trimmed.is_empty() {
        return Ok(None);
    }
    giteam_core::command_runner::validate_repo_path(&trimmed)?;
    Ok(Some(trimmed))
}

fn serve(warmup: bool, json: bool) -> Result<(), String> {
    if warmup {
        thread::spawn(|| {
            opencode::warmup_managed_opencode_service();
        });
    }
    control::start_control_server();
    print_status(json)?;
    eprintln!("giteam control server running, press Ctrl+C to stop");

    let running = Arc::new(AtomicBool::new(true));
    let signal = Arc::clone(&running);
    ctrlc::set_handler(move || {
        signal.store(false, Ordering::Relaxed);
    })
    .map_err(|e| format!("failed to install Ctrl+C handler: {e}"))?;

    while running.load(Ordering::Relaxed) {
        thread::sleep(Duration::from_millis(250));
    }

    control::stop_control_server();
    opencode::shutdown_managed_opencode_service();
    Ok(())
}

fn main() {
    let cli = Cli::parse();
    let result = match cli.command.unwrap_or(Commands::Serve { warmup: true, json: false }) {
        Commands::Serve { warmup, json } => serve(warmup, json),
        Commands::Status { json } => print_status(json),
        Commands::PairCode { refresh, json } => print_pair_code(refresh, json),
        Commands::Config { command } => match command {
            ConfigCommands::Get { json } => print_config(json),
            ConfigCommands::Set(args) => update_config(args),
        },
        Commands::Doctor {
            repo_path,
            warmup,
            json,
        } => run_doctor(repo_path, warmup, json),
    };

    if let Err(err) = result {
        eprintln!("{err}");
        std::process::exit(1);
    }
}
