# `@giteam/cli`

`giteam` 的终端版控制服务，复用现有 Rust 服务逻辑，对外暴露与桌面端一致的局域网控制接口，供移动端发现和连接。

## 当前状态

- 已支持通过 npm `bin` 入口执行 `giteam`
- 当前仍依赖本机 Rust/Cargo 环境
- `apps/cli` 已不再直接依赖 `tauri`
- 当前通过 `crates/giteam-core` 复用服务逻辑，但源码仍暂时挂在桌面端命令文件上

## 本地使用

```bash
cd apps/cli
node ./bin/giteam.js status --json
node ./bin/giteam.js serve
```

如果本地已编译过二进制，`bin/giteam.js` 会优先直接启动：

- `target/release/giteam-cli`
- `target/debug/giteam-cli`

否则会自动回退到：

```bash
cargo run -- <args>
```

## 计划中的下一步

- 把共享服务源码彻底迁到 `crates/giteam-core`
- 补充更多纯终端命令，例如 `doctor` / `config`
